import ScrollTunnel from "@/components/ScrollTunnel";

export default function Home() {
  return (
    <div className="min-h-screen bg-black text-white">
      <ScrollTunnel />
    </div>
  );
}
